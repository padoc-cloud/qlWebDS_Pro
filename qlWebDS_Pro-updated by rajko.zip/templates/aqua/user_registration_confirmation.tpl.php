<table class="site_info">
	<tr>
 		<td align="center">
  			<div style="text-align: left; valign: top; width: 85%;">
				<table class="site_info">
					<tr>
						<td align="left" valign="middle">
    						<font color="#0066CC">
								<b>Your registration was successful. <br>
								Confirmation message was sent to the e-mail address you provided.</b>
							</font>
								<br><br><b>Your User Name is:</b>
							<font color="#0066CC">
								{user name}
							</font>
						</td>
					</tr>
					<tr>
						<td align="center" valign="middle">
							<span class="{url_disp}">
							<a href="{home_url}?page=login" title="Login">
								<u>Login</u>
							</a>
							</span>
						</td>
					</tr>
				</table>
  			</div>
 		</td>
	</tr> 
</table>
