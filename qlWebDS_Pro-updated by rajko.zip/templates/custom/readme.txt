Theme Name: Custom
Theme URI: http://www.qlweb.com
Description: This is a Duplicate of the Free Default CSS Template for qlWebDS Pro v. 6.3.*. Use it to develop new CSS Templates. This way you'll always have a clean copy of the Default one.
Version: 6.0
Author: qlWeb.com
Author URI: http://www.qlweb.com
