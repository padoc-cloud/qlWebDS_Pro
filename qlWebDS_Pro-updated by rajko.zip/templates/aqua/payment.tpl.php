<h3>Thank You!</h3>
Your transaction has been completed. A receipt for your purchase has been emailed to you. <br>
You may log into your PayPal account at 
<a href="https://www.paypal.com/us/" target="_blank">
	<u>www.paypal.com/us</u>
</a> to view all details about this transaction. <br><br>
{if pay_b4_submit==1}
Please click <u><a href="{address}">here</a></u> to continue with your submission.
{end pay_b4_submit}
