<?php
  
  $tmp_tpl = new TemplateClass(); 
  $tmp_tpl->SetTemplate('404.tpl.php');  
  $tpl_main = $tmp_tpl->Get();
        
?>
