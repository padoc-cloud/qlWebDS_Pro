Theme Name: Blue
Theme URI: http://www.directorycheck.com
Description: Free CSS Template for qlWebDS Pro v. 6.3.*
Version: 6.0
Author: DirectoryCheck.com
Author URI: http://www.directorycheck.com
