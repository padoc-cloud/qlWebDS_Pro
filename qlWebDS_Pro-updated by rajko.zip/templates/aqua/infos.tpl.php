<table class="site_info">
	<tr>
 		<td class="{featured/normal}">
  			<a href="./" class="link1">
				{home}
			</a>
  			<hr>
 		</td>
	</tr>
	<tr>
 		<td>
			{content}
		</td>
	</tr>
</table>
