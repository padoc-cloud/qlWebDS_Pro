Theme Name: Aqua
Theme URI: http://www.fordirectoryowners.com
Description: Sponsored CSS/XHTML Template for qlWebDS Pro v. 6.3.*
Version: 6.0
Author: ForDirectoryOwners.com
Author URI: http://www.fordirectoryowners.com
