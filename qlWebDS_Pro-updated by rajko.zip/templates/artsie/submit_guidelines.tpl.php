<h3>Submission Guidelines and Terms of Service</h3>
{submit_guidelines}
<p>
