{row subcategories}
	<a href="{sub_url}[1]" class="sub">
		{sub_name}[1]
	</a>
	<br>
{/row subcategories}
