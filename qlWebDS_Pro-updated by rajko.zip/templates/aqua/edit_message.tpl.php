<table class="form_o">
	<tbody>
		<tr>
 			<td>
 				<div class="info">{message}</div>
 			</td>
 		</tr>
 		<tr>
 			<td style="text-align: center;">
 				<br><a href="?page=user_account"><u>Back to User Account</u></a>
 			</td>
		</tr>
	</tbody>
</table>
