<?php

    $g_user->Logout();
    header('location: ../');
    
?>
