Theme Name: Artsie
Theme URI: http://www.categorydirectory.com
Description: Sponsored CSS/XHTML Template for qlWebDS Pro v. 6.3.*
Version: 6.0
Author: CategoryDirectory.com
Author URI: http://www.categorydirectory.com
