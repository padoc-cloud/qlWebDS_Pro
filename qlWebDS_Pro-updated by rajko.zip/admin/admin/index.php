<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
	<head>
		<title>Access to this File/Directory is Not Authorized</title>
			<meta name="robots" content="noindex, nofollow">
			<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
	</head>
	<body>
<div style="text-align: center;">
	<div style="text-align: left; margin: 30px auto 0 auto; width: 600px; background-color: #F6F6F9; border: 1px solid #DDD; padding: 30px; font-family: Tahoma;">
		<h2>Unauthorized Access!</h2>
		<div>
			<p>Please correct the URL or 
			<a href="../" title="Return to the Home Page">
				Return to the Home Page
			</a>
			</p>
		</div>
	</div>
	<p>
	<a href="http://www.qlWebScripts.com" title="qlWeb Family of PHP and MySQL Internet Scripts">
		<img src="http://www.qlWebScripts.com/images/qlWebDS_80x15.gif" border="0" width="80" height="15" alt="qlWeb Family of PHP and MySQL Internet Scripts">
	</a>
	</p>
	<p>
	<b>Powered by:</b> 
	<a href="http://www.qlWebScripts.com" title="qlWeb Family of Webserver Internet Scripts">
		qlWeb Family of Webserver Internet Scripts
	</a>
	</p>
	<p><b>
	<script src="../java_scripts/copyright_years.js" type="text/javascript" language="JavaScript">
	</script>
	</b></p>
</div>
	</body>
</html>
