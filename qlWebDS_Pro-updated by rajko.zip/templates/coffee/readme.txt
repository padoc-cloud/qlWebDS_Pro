Theme Name: Coffee
Theme URI: http://www.regularlink.com
Description: Free CSS Template for qlWebDS Pro v. 6.3.*
Version: 6.0
Author: RegularLink.com
Author URI: http://www.regularlink.com
