document.write('Copyright &copy; ' );
document.write('2007-');
document.write(new Date().getFullYear());
document.write(' Contact USA, Inc. All Rights Reserved.');
