<table class="form_o">
	<tbody>
		<tr>
    		<td>
        		<table class="form_i">
         			<tbody>
           				<tr>
           					<td class="nag" colspan="2">{lang logout title}</td>
          				</tr>
				        <tr>
				        	<td class="lCForm" style="text-align: center;" colspan="2">{lang logout message}</td>
				        </tr>
         			</tbody>
        		</table>
    		</td>
		</tr>
	</tbody>
</table>
