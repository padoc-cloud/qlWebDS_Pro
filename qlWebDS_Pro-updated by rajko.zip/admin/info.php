<?php

  switch ($param) {
    case '001':
      $tpl_main['{content}'] = ERROR_001;
      break;
    default:
      break;
  }

?>
