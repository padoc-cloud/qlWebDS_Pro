Theme Name: Diamonds
Theme URI: http://www.directorysnob.com
Description: Sponsored CSS/XHTML Template for qlWebDS Pro v. 6.3.*
Version: 6.0
Author: DirectorySnob.com
Author URI: http://www.directorysnob.com
